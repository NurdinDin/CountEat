package com.dicoding.counteat.data.pref

class SignUpModel {
    
}