package com.dicoding.counteat.ui.insert_tb_bb

import androidx.lifecycle.ViewModel
import com.dicoding.counteat.data.repository.AppRepository

class TBbBbViewModel(private val repository: AppRepository): ViewModel() {

    fun tbUser(username: String, tb: String, bb: String, age: String) =
        repository.bmiUser(username, tb, bb, age)
}