package com.dicoding.counteat.ui.Register.signup

import androidx.lifecycle.ViewModel
import com.dicoding.counteat.data.repository.AppRepository

class SignUpViewModel (private val repository: AppRepository): ViewModel() {
    fun signUp(name: String, email: String, password: String, gender: String) =
        repository.register(name, email, password, gender)
}