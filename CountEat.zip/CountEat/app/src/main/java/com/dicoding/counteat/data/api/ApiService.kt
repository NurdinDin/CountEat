package com.dicoding.counteat.data.api

import com.dicoding.counteat.data.response.BMIResponse
import com.dicoding.counteat.data.response.LoginResponse
import com.dicoding.counteat.data.response.RegisterResponse
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST
import retrofit2.http.Path

interface ApiService {
    @FormUrlEncoded
    @POST("register")
    suspend fun register(
        @Field("username") name: String,
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("gender") gender: String
    ) : RegisterResponse

    @FormUrlEncoded
    @POST("login")
    suspend fun login(
        @Field("username") username: String,
        @Field("email") email: String,
        @Field("password") password: String
    ) : LoginResponse

    @FormUrlEncoded
    @POST("updatedetail/{username}")
    suspend fun bmi(
        @Path("username") username: String,
        @Field("tinggibadan") tb: String,
        @Field("beratbadan") bb: String,
        @Field("umur") age: String
    ) : BMIResponse

    /*@GET("updatedetail/{username}")
    fun getUsername(
        @Path("username") username: String,
    )*/
}